package com.adyen.android.assignment.money

interface MonetaryElement {
    val minorValue: Int
}
