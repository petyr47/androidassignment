package com.adyen.android.assignment.api.model.search

data class GeoBounds(
    val circle: Circle = Circle()
)