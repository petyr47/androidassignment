package com.adyen.android.assignment.api.model.search

data class Parent(
    val fsq_id: String = "",
    val name: String = ""
)