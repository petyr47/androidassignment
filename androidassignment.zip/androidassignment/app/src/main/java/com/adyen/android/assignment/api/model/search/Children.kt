package com.adyen.android.assignment.api.model.search

data class Children(
    val fsq_id: String = "",
    val name: String = ""
)