package com.adyen.android.assignment.api.model.search

data class Geocodes(
    val main: Main = Main()
)