package com.adyen.android.assignment.api.model.search

data class Circle(
    val center: Center = Center(),
    val radius: Int = 0
)