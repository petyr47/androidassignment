package com.adyen.android.assignment.api.model.details

data class Geocodes(
    val main: Main = Main()
)